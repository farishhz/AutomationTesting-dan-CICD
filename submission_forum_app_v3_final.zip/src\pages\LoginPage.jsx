import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { asyncSetAuthUser } from '../states/authUser/reducer';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { authUser } = useSelector((state) => state);

  useEffect(() => {
    if (authUser) {
      navigate('/');
    }
  }, [authUser, navigate]);

  const onLogin = (e) => {
    e.preventDefault();
    dispatch(asyncSetAuthUser({ email, password }));
  };

  return (
    <div className="login-page flex items-center justify-center pt-20">
      <div className="glass-card p-10 w-full max-w-md">
        <h2 className="text-3xl font-extrabold mb-2 text-gradient">Welcome Back</h2>
        <p className="text-text-muted mb-8">Login to join the conversation.</p>

        <form onSubmit={onLogin}>
          <div className="input-group">
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              required
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-full justify-center py-3 mt-4">
            Sign In
          </button>
        </form>

        <p className="mt-8 text-center text-text-muted">
          Don&apos;t have an account?
          {' '}
          <Link to="/register" className="text-primary font-bold hover:underline">Sign up for free</Link>
        </p>
      </div>
      <style>
        {`
        .pt-20 { padding-top: 5rem; }
        .p-10 { padding: 2.5rem; }
        .w-full { width: 100%; }
        .max-w-md { max-width: 28rem; }
      `}
      </style>
    </div>
  );
}

export default LoginPage;
